set_property SRC_FILE_INFO {cfile:C:/Users/lxkearns/Downloads/engr-202-vivado-projects-main/engr-202-vivado-projects-main/lab-4-2/main.xdc rfile:../../../../../lab-4-2/main.xdc id:1} [current_design]
set_property src_info {type:XDC file:1 line:1 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN Y14   IOSTANDARD LVCMOS33 } [get_ports { RGB_led_B[0] }]; #IO_L8N_T1_34 Schematic=LD11_R
set_property src_info {type:XDC file:1 line:2 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN Y16   IOSTANDARD LVCMOS33 } [get_ports { RGB_led_B[1] }]; #IO_L7P_T1_34 Schematic=LD11_G
set_property src_info {type:XDC file:1 line:3 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN Y17   IOSTANDARD LVCMOS33 } [get_ports { RGB_led_B[2] }]; #IO_L7N_T1_34 Schematic=LD11_B
set_property src_info {type:XDC file:1 line:5 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN R17   IOSTANDARD LVCMOS33 } [get_ports { coolant_temp }]; #IO_L19N_T3_VREF_34 Schematic=SW0
set_property src_info {type:XDC file:1 line:6 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN U20   IOSTANDARD LVCMOS33 } [get_ports { coolant_level }]; #IO_L15N_T2_DQS_34 Schematic=SW1
set_property src_info {type:XDC file:1 line:7 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN R16   IOSTANDARD LVCMOS33 } [get_ports { oil_temp }]; #IO_L19P_T3_34 Schematic=SW2
set_property src_info {type:XDC file:1 line:8 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN N16   IOSTANDARD LVCMOS33 } [get_ports { oil_level }]; #IO_L21N_T3_DQS_AD14N_35 Schematic=SW3
